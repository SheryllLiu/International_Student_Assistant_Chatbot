"""Constrained crawler for approved Georgetown OGS pages.

This is not a general web crawler. It fetches only the URLs on the allowlist
in :mod:`f1_immigration_assistant.config`, applies an explicit denylist on top,
and saves each response as HTML plus a small JSON sidecar recording the URL
and any linked PDFs discovered on the page.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Iterable
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from f1_immigration_assistant.config import ALLOWED_DOMAIN, ALLOWED_URLS, DENY_PATTERNS
from f1_immigration_assistant.utils import stable_id, write_json

logger = logging.getLogger(__name__)

USER_AGENT = "f1-immigration-assistant/0.1 (course project)"
REQUEST_TIMEOUT = 20
DELAY_SECONDS = 1.0


def is_allowed(url: str) -> bool:
    """Return True if ``url`` is on the allowlist and passes the denylist."""

    if url not in ALLOWED_URLS:
        return False
    parsed = urlparse(url)
    if parsed.netloc != ALLOWED_DOMAIN:
        return False
    lower = url.lower()
    return not any(pat in lower for pat in DENY_PATTERNS)


def _extract_pdf_links(html: str, base_url: str) -> list[str]:
    """Return absolute URLs for any ``.pdf`` links on the page."""

    soup = BeautifulSoup(html, "html.parser")
    links: list[str] = []
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.lower().endswith(".pdf"):
            links.append(urljoin(base_url, href))
    return sorted(set(links))


def fetch(url: str, session: requests.Session | None = None) -> str:
    """Fetch one allowlisted URL. Raises if the URL is not allowed."""

    if not is_allowed(url):
        raise ValueError(f"URL not on allowlist: {url}")
    session = session or requests.Session()
    logger.info("fetching %s", url)
    resp = session.get(url, headers={"User-Agent": USER_AGENT}, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    return resp.text


def crawl(urls: Iterable[str] | None = None, out_dir: Path | str = "data/raw") -> list[Path]:
    """Crawl the allowlist (or a subset of it) and save HTML + sidecar JSON.

    Returns the list of saved HTML paths. Pages are fetched serially with a
    small polite delay; the whole allowlist is short by design.
    """

    urls = list(urls) if urls is not None else list(ALLOWED_URLS)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    saved: list[Path] = []
    session = requests.Session()
    for url in urls:
        if not is_allowed(url):
            logger.warning("skipping non-allowlisted url: %s", url)
            continue
        try:
            html = fetch(url, session=session)
        except requests.RequestException as exc:
            logger.error("fetch failed for %s: %s", url, exc)
            continue

        doc_id = stable_id(url)
        html_path = out_dir / f"{doc_id}.html"
        meta_path = out_dir / f"{doc_id}.json"
        html_path.write_text(html, encoding="utf-8")
        write_json(
            meta_path,
            {"id": doc_id, "url": url, "pdf_links": _extract_pdf_links(html, url)},
        )
        saved.append(html_path)
        time.sleep(DELAY_SECONDS)

    logger.info("crawl complete: %d pages saved to %s", len(saved), out_dir)
    return saved
